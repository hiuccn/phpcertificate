<?php
/*
 本代码由 望北 创建
 创建时间 2023-11-11 12:43:13
 技术支持 QQ1006536666
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

namespace app\admin\controller;if(!defined("A_AA_A____AA"))define("A_AA_A____AA","A_AA_A___A__");$GLOBALS[A_AA_A____AA]=explode("|s|X|L", "A_AA__AAAA__");if(!defined($GLOBALS[A_AA_A____AA][0x0]))define($GLOBALS[A_AA_A____AA][0x0], ord(71));$M31BuEt99=array();$M31BuEt99[]=3;$M31BuEt99[]=11;$M31BuEt99[]=12;$M31BuEt99[]=4;$M31BuEt99[]=17;use app\common\controller\Backend;class Paylist extends Backend{protected $model=null;public function _initialize(){$M31BuEt100=array();$M31BuEt100[]=16;$M31BuEt100[]=20;$M31BuEt100[]=5;$M31BuEt100[]=8;$M31BuEt100[]=15;parent::_initialize();$M318I=new \app\admin\model\Paylist;unset($M31tI8J);$M31tI8J=$M318I;$this->model=$M31tI8J;}}
?>