<?php

namespace app\admin\controller;

use app\admin\model\Admin;
use app\admin\model\Deviceslist;
use app\common\controller\Backend;
use app\common\model\Attachment;
use fast\Date;
use think\Db;

/**
 * 控制台
 *
 * @icon   fa fa-dashboard
 * @remark 用于展示当前系统中的统计数据、统计报表及重要实时数据
 */
class Dashboard extends Backend
{

    /**
     * 查看
     */
    public function index()
    {
        try {
            \think\Db::execute("SET @@sql_mode='';");
        } catch (\Exception $e) {

        }
        $column = [];
        $starttime = Date::unixtime('day', -6);
        $endtime = Date::unixtime('day', 0, 'end');
        $joinlist =Db::name("deviceslist")
            ->where('chi', 0)
            ->where('shouhou', 0)
            ->where('type', 0)
            ->field('base64mp,base64p12',true)
            ->where('tjtime', 'between time', [$starttime, $endtime])
            ->field('tjtime, COUNT(*) AS nums, DATE_FORMAT(FROM_UNIXTIME(tjtime), "%Y-%m-%d") AS join_date')
            ->group('join_date')
            ->select();
        $joinlist1 =Db::name("deviceslist")
            ->where('chi', 0)
            ->where('shouhou', 0)
            ->where('type', 1)
            ->field('base64mp,base64p12',true)
            ->where('tjtime', 'between time', [$starttime, $endtime])
            ->field('tjtime, COUNT(*) AS nums, DATE_FORMAT(FROM_UNIXTIME(tjtime), "%Y-%m-%d") AS join_date')
            ->group('join_date')
            ->select();
        for ($time = $starttime; $time <= $endtime;) {
            $column[] = date("Y-m-d", $time);
            $time += 86400;
        }
        $userlist = array_fill_keys($column, 0);
        $userlist1 = array_fill_keys($column, 0);
        foreach ($joinlist as $k => $v) {
            $userlist[$v['join_date']] = $v['nums'];
        }
       foreach ($joinlist1 as $k => $v) {
            $userlist1[$v['join_date']] = $v['nums'];
        }
        $dbTableList = Db::query("SHOW TABLE STATUS");
        $addonList = get_addon_list();
        $totalworkingaddon = 0;
        $totaladdon = count($addonList);
        foreach ($addonList as $index => $item) {
            if ($item['state']) {
                $totalworkingaddon += 1;
            }
        }
         $notice_list = Db::name('deviceslist')
            ->where('id','<>',0)
          
            ->field(['base64mp','base64p12'],true)
            ->where('chi', 0)
            ->select();  
            
        $this->view->assign([
            'totaluser'         => count($notice_list),
            'totaladdon'        => $totaladdon,
            'totaladmin'        => Admin::count(),
            'totalcategory'     => \app\common\model\Category::count(),
            'todayusersignup'   => Deviceslist::whereTime('tjtime', 'today')->where('shouhou', 0)->field(['base64mp','base64p12'],true)->where('chi', 0)->count(),
            'todayuserlogin'    => Deviceslist::whereTime('tjtime', '-365 days')->where('shouhou', 0)->field(['base64mp','base64p12'],true)->where('chi', 0)->count(),
            'sevendau'          => Deviceslist::whereTime('tjtime', '-90 days')->where('shouhou', 0)->field(['base64mp','base64p12'],true)->where('chi', 0)->count(),
            'thirtydau'         => Deviceslist::whereTime('tjtime', '-30 days')->where('shouhou', 0)->field(['base64mp','base64p12'],true)->where('chi', 0)->count(),
            'threednu'          => Deviceslist::whereTime('tjtime', '-3 days')->where('shouhou', 0)->field(['base64mp','base64p12'],true)->where('chi', 0)->count(),
            'zrxz'          => Deviceslist::whereTime('tjtime', '-1 days')->where('shouhou', 0)->field(['base64mp','base64p12'],true)->where('chi', 0)->count(),
            'byxz'          => Deviceslist::whereTime('tjtime', '-15 days')->where('shouhou', 0)->field(['base64mp','base64p12'],true)->where('chi', 0)->count(),
            'sevendnu'          => Deviceslist::whereTime('tjtime', '-7 days')->where('shouhou', 0)->field(['base64mp','base64p12'],true)->where('chi', 0)->count(),
            'dbtablenums'       => count($dbTableList),
            'dbsize'            => array_sum(array_map(function ($item) {
                return $item['Data_length'] + $item['Index_length'];
            }, $dbTableList)),
            'totalworkingaddon' => $totalworkingaddon,
            'attachmentnums'    => Attachment::count(),
            'attachmentsize'    => Attachment::sum('filesize'),
            'picturenums'       => Attachment::where('mimetype', 'like', 'image/%')->count(),
            'picturesize'       => Attachment::where('mimetype', 'like', 'image/%')->sum('filesize'),
        ]);

        $this->assignconfig('column', array_keys($userlist));
        $this->assignconfig('userdata', array_values($userlist));
        $this->assignconfig('userdata1', array_values($userlist1));

        return $this->view->fetch();
    }

}