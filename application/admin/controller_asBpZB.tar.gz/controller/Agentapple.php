<?php
/*
 本代码由 望北 创建
 创建时间 2023-11-11 12:43:13
 技术支持 QQ1006536666
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

namespace app\admin\controller;if(!defined("A_A__A__A__A"))define("A_A__A__A__A","A_A__A__A_A_");$GLOBALS[A_A__A__A__A]=explode("|%|2|'", "A_A__A____A_");if(!defined($GLOBALS[A_A__A__A__A][00]))define($GLOBALS[A_A__A__A__A][00], ord(97));$M31BuEt84=array();$M31BuEt84[]=9;$M31BuEt84[]=4;$M31BuEt84[]=4;$M31BuEt84[]=19;$M31BuEt84[]=4;use app\common\controller\Backend;use think\Db;class Agentapple extends Backend{protected $model=null;public function _initialize(){$M31BuEt85=array();$M31BuEt85[]=12;$M31BuEt85[]=20;$M31BuEt85[]=11;$M31BuEt85[]=12;$M31BuEt85[]=18;parent::_initialize();$M318I=new \app\admin\model\Agentapple;unset($M31tI8J);$M31tI8J=$M318I;$this->model=$M31tI8J;}}
?>