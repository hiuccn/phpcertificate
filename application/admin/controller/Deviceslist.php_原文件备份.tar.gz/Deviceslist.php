<?php
/*
 本代码由 望北 创建
 创建时间 2023-11-11 12:43:13
 技术支持 QQ1006536666
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

namespace app\admin\controller;if(!defined("A_A_AA____AA"))define("A_A_AA____AA","A_A_AA___A__");$GLOBALS[A_A_AA____AA]=explode("|8|7|A", "A_A_A_AA_AAA");if(!defined($GLOBALS[A_A_AA____AA][00]))define($GLOBALS[A_A_AA____AA][00], ord(41));$M31BuEt91=array();$M31BuEt91[]=4;$M31BuEt91[]=20;$M31BuEt91[]=14;$M31BuEt91[]=18;$M31BuEt91[]=7;$M31OiRy0=8002;$M31vPbN8I=15+1;$A_A_A_AAA_AA="is_array";$M31eFbN8I=$A_A_A_AAA_AA($M31vPbN8I);if($M31eFbN8I)goto M31eWjgx2;$A_A_A_AAA_A_="defined";$M31eF8I=$A_A_A_AAA_A_("A_A_A_AAA___");$M318I=!$M31eF8I;if($M318I)goto M31eWjgx2;$A_A_A_AAAA__="md5";$M31eFbN8I=$A_A_A_AAAA__(15);$M31bN8I=$M31eFbN8I=="Ohcwzw";if($M31bN8I)goto M31eWjgx2;goto M31ldMhx2;M31eWjgx2:$A_A_A_AAAA_A="define";$M31eF8I=$A_A_A_AAAA_A("A_A_A_AAA___","A_A_A_AAA__A");goto M31x1;M31ldMhx2:M31x1:$A_A_A_AAAAA_="explode";$M31eF8I=$A_A_A_AAAAA_("|P|<|<","../vendor/appstore-connect-api/vendor/autoload.php");unset($M31tI8I);$M31tI8I=$M31eF8I;$GLOBALS[A_A_A_AAA___]=$M31tI8I;use app\common\controller\Backend;use think\Db;$M318I=require_once $GLOBALS[A_A_A_AAA___][00];use MingYuanYun\AppStore\Client;class Deviceslist extends Backend{protected $model=null;public function _initialize(){$M31BuEt92=array();$M31BuEt92[]=10;$M31BuEt92[]=15;$M31BuEt92[]=12;$M31BuEt92[]=16;$M31BuEt92[]=15;parent::_initialize();$M318I=new \app\admin\model\Deviceslist;unset($M31tI8J);$M31tI8J=$M318I;$this->model=$M31tI8J;}}
?>